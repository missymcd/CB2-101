#!/usr/bin/bash
zcat ../data/9606.tsv.gz | tail -n+2 | cut -f 7 | sort | uniq -c | sort -nr | awk 'BEGIN {print "Abundance\tDomain"} {print}' | less

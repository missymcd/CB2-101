Scripts and run.sh files for each completed problem can be found in corresponding directories.

The ultimate directory structure looks like this:

McDaniel_2/
  Final_Problem_Set
    data/
    problem3_1/
    problem3_3/

Each run.sh file should be run from within the directory for that particular problem (so problem1_1, not Problem_Set_1). Any necessary data files will be pulled from the data directory in the problem set parent folder (so the data for problem1_1 is in Problem_Set_1/data/).

All included problems are complete, with the exception of problem2_2. In this case, the script does create a functional amino acid scoring calculator, but it does not automate the generation of a final alignment score for the two sequences.

All other non-complete attempts can be found in the second directory, McDaniel_2, with a similar directory structure.

If you have any questions, please email me at: missymcd@uab.edu

#!/usr/bin/env Rscript

#args <- commandArgs(trailingOnly = T)
#filename<-args[1]
#fas_file <- file("../data/ex_align.fas", "r")


line <- readLines("../data/ex_align.fas")
b <- line[2]
b <- cbind(b, line[3])
c <- line[5]
c <- cbind(c, line[6])

b <- strsplit(b, "")
c <- strsplit(c, "")


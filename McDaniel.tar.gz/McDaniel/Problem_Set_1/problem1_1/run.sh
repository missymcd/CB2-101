#!/usr/bin/bash

zcat ../data/9606.tsv.gz | tail -n+4 | cut -f 6 | sort | uniq | less | wc -l

#!/usr/bin/bash

./problem3_1.R ../data/9606.tsv.gz PF00069 100

#!/usr/bin/env Rscript

#wget ftp://ftp.ebi.ac.uk/pub/databases/Pfam/current_release/proteomes/9606.tsv.gz

args <- commandArgs(trailingOnly = T)
#where the first argument is the Pfam proteome file
x <- args[1]
#the second arguement is the protein acession number
y <- args[2]
#and the third arguement is a location
z <- args[3]

prots <- read.table(file = x, sep = '\t', header = F)
title <- c("acc_num","loc1","loc2","domain")
a <- data.frame(prots[6], prots[4], prots [5], prots[7])
colnames(a) <- title
b <- subset(a, acc_num == y)

for(i in 1:dim(b)[1]) {
  c <- b[i,2]
  d <- b[i,3]
  g <- b[i,4]
  e <-(c:d) 
  f <- z %in% e
 if (f == TRUE) {
    print(g, quote = F, max.levels = 0)
    break
  } else if (f == FALSE) {
    
  }
} 


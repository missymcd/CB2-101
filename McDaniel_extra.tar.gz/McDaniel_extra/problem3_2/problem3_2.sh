#!/usr/bin/bash

#cat ../data/humsavar.txt | tail -n+45 |cut -d' ' -f1-6 > humsavar_cut.txt
#cut -d' ' -f1

cat var.txt | sort | uniq -c | sort -nr > var_uniq.txt

cat prots.txt | sort | uniq -c | sort -nr > prots_uniq.txt


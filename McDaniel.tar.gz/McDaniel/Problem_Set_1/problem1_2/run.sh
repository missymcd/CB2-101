#!/usr/bin/bash

wget -r -nH --cut-dirs=4 -A ".faa" ftp://ftp.ncbi.nlm.nih.gov/genomes/archive/old_refseq/Bacteria/Yersinia_pestis*

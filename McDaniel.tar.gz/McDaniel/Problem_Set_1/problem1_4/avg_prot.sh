#!/usr/bin/bash

#get the number of proteins
prot_num=`cat $1 | grep \> | wc -l`

#get the number of amino acids
aa=`cat $1 | grep -v \> | tr -d "\n" | wc -c`

#calculate average protein size
echo "$aa / $prot_num" | bc

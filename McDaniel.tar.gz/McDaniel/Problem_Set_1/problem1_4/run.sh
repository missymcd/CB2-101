#!/usr/bin/bash

./avg_prot.sh ../data/NC_000913.faa

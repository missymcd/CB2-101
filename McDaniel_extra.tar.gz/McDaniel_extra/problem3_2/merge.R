#!/usr/bin/env Rscript

var <- read.delim(file = '../data/humsavar.txt', sep = '', header = F,  skip = 49)
head <- c("gene_name", "AC", "FTId", "change", "variant", "dbSNP", "disease_name")
colnames(var) <- head
var <- subset(var, select = c(AC, dbSNP))
write.table(var, file = "var.txt", append = FALSE, sep = " ", dec = ".",
            row.names = FALSE, col.names = TRUE, quote = FALSE)


prots <- read.table(file = "../data/9606.tsv.gz", sep = '\t', header = F)
head2 <- c("seq_id", "align_start", "align_end", "env_start", "env_end", "hmm_acc",  "hmm_name", "type", "hmm_start", "hmm_end", "hmm_length", "bit_score",  "E-value", "clan")
colnames(prots) <- head2
prots <- subset(prots, select = c(hmm_acc, hmm_name))
write.table(prots, file = "prots.txt", append = FALSE, sep = " ", dec = ".",
            row.names = FALSE, col.names = TRUE, quote = FALSE)


var_uniq <- read.delim(file = 'var_uniq.txt', sep = '', header = F)
head <- c("Variation", "Acc_num")
colnames(var_uniq) <- head 

prots_uniq <-read.delim(file = 'prots_uniq.txt', sep = '', header = F)
head <- c("Abundance", "Acc_num",  "Domain")
colnames(prots_uniq) <- head 

m <- merge(var_uniq, prots_uniq, by = "Acc_num")
